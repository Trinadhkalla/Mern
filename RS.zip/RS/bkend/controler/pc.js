let axios = require("axios")
const prmd = require("../model/pm")
const CreateDatabase = async (req, res) => {
    try {
        const response = await axios.get('https://s3.amazonaws.com/roxiler.com/product_transaction.json')
        const product = response.data

        await prmd.deleteMany()
        await prmd.insertMany(product)

        res.json({ message: 'Database initialized with seed data.' })
    } catch (error) {
        res.json({ message: 'Error initializing the database.' })
    }
}

const getAllData = async (req, res) => {
    try {
        const product = await prmd.find()
        res.json(product)
    } catch (error) {
        res.json({ message: 'Error fetching products.' })
    }
}

const getTransactions = async (req, res) => {
    try {
        const { search, page = 1, perPage = 10 } = req.query
        const currentPage = parseInt(page)
        const itemsPerPage = parseInt(perPage)

        let query = {}

        if (search) {
            const searchRegex = new RegExp(search, 'i')
            query = {
                $or: [
                    { title: { $regex: searchRegex } },
                    { description: { $regex: searchRegex } },
                    { price: { $regex: searchRegex } }
                ]
            }
        }

        const products = await prmd.find(query)
            .skip((currentPage - 1) * itemsPerPage)
            .limit(itemsPerPage)

        const totalProducts = await prmd.countDocuments(query)

        res.json({
            page: currentPage,
            perPage: itemsPerPage,
            totalRecords: totalProducts,
            totalPages: Math.ceil(totalProducts / itemsPerPage),
            products
        })
    } catch (error) {
        res.json({ message: 'Error fetching transactions.' })
    }
}

const getStatistics = async (req, res) => {
    try {
        const { month } = req.query;

        if (!month) {
            return res.json({ message: "Month is required." });
        }

        const startOfMonth = new Date();
        startOfMonth.setMonth(parseInt(month) - 1);
        startOfMonth.setDate(1);
        startOfMonth.setHours(0, 0, 0, 0);

        const endOfMonth = new Date(startOfMonth);
        endOfMonth.setMonth(endOfMonth.getMonth() + 1);

        const soldItems = await prmd.find({
            sold: true,
            $expr: {
                $eq: [{ $month: "$dateOfSale" }, parseInt(month)]
            }
        });

        const unSoldItems = await prmd.find({
            sold: false,
            $expr: {
                $eq: [{ $month: "$dateOfSale" }, parseInt(month)]
            }
        });

        const totalSaleAmount = soldItems.reduce((total, item) => total + item.price, 0);
        const totalSoldItems = soldItems.length;
        const totalUnSoldItems = unSoldItems.length;

        res.json({
            totalSaleAmount,
            totalSoldItems,
            totalUnSoldItems,
        });
    } catch (error) {
        res.json({ message: 'Error getting sales statistics.' });
    }
}






const getCombinedData = async (req, res) => {
    try {
        const { month } = req.query;

        if (!month) {
            return res.json({ message: "Month is required." });
        }

        const statsResponse = await axios.get(`http://localhost:5000/stats/?month=${month}`);
        const statistics = statsResponse.data;

        const barChartResponse = await axios.get(`http://localhost:5000/barchart?month=${month}`);
        const barChartData = barChartResponse.data;

        const pieChartResponse = await axios.get(`http://localhost:5000/piechart?month=${month}`);
        const pieChartData = pieChartResponse.data;

        const combinedResponse = {
            statistics,
            barChartData,
            pieChartData,
        };

        res.json(combinedResponse);
    } catch (error) {
        res.json({ message: 'Error fetching combined data.' });
    }
};


module.exports = {
    CreateDatabase,
    getAllData,
    getTransactions,
    getStatistics,
    getCombinedData
}