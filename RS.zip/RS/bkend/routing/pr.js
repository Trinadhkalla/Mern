let express = require("express")
const { getTransactions, getCombinedData, getStatistics, CreateDatabase, getAllData } = require("../controler/pc")

let route = new express.Router()

route.get("/initailize",CreateDatabase)
route.get("/getprod",getAllData)
route.get('/transaction/:year/:month', getTransactions)
route.get("/statistics",getStatistics)
route.get("/combined",getCombinedData)

module.exports = route