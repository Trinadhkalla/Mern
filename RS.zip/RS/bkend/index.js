let express = require("express")
let mongoose = require("mongoose")
let axios = require("axios")
const route = require("./routing/pr")
let app = express()
let cors = require("cors")
app.use(cors())
app.use(express.json())

mongoose.connect("mongodb://localhost:27017/prod").then(()=>{
    console.log("database connection was okay")
}).catch(()=>{
    console.log("Connection was Failed")
})

app.use("/", route)
app.listen(6500)